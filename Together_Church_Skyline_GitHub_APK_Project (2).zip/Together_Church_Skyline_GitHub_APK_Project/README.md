# Together Church Skyline — Android APK build

This repository is prepared to build two Android debug APKs with GitHub Actions:
- Pastor Admin
- Church Member

## Build from a phone
1. Create a new GitHub repository.
2. Upload all files and folders from this project to the repository root.
3. Open the repository's **Actions** tab.
4. Select **Build Pastor and Member APKs**.
5. Tap **Run workflow** and confirm.
6. When the workflow finishes, open the run and download the two APK artifacts.

The first build may take several minutes. These are debug APKs for testing/direct installation, not Play Store release-signed APKs.

Important: APK packaging does not itself verify Supabase permissions or add background push notifications. Test sign-in, prayer posting, private messaging, and role restrictions before distributing.
